
var access_token;
var ready = false;
 document.addEventListener("DOMContentLoaded", function(event) {
   console.log("DOM fully loaded and parsed");
   ready = true;
 });

  chrome.extension.onMessage.addListener(
    function (request, sender, sendResponse) {
      switch (request.directive) {

        case "popup-click":
          if(confirm("popup-click!")){
            //chrome.identity.getAuthToken({'interactive':true}, function(token) {
            chrome.identity.getProfileUserInfo(function(userInfo){
              if (chrome.runtime.lastError) {
                alert(chrome.runtime.lastError);

              } else {
                access_token = JSON.stringify(userInfo);
                alert(access_token);
              }
            });
          }
          if(ready) {
            // execute the content script that lets the user draw a rectangle
            startKlipper();
            startKlipper();
            sendResponse({msg: "Klipping..."}); // sending back empty response to sender
          }
          break;

        case "capture":
          //Take a screen shot and send to kahoots server
          chrome.tabs.captureVisibleTab(null, function (img) {
            var xhr = new XMLHttpRequest();
            var formData = new FormData();
            formData.append("content", img);
            formData.append("rect", JSON.stringify(request.rect));
            formData.append("source", request.source);
            xhr.open("POST", "http://localhost:9000/api/clips/file-upload/", true);
            xhr.send(formData);
          });
          sendResponse({msg: access_token});
          break;
        case "signed-in":

          break;
        default:
          // helps debug when request directive doesn't match
          alert("Unmatched request of '" + request + "' from script to background.js from " + sender);
      }
    }
  );

 function startKlipper(){
   chrome.tabs.executeScript(null, { // defaults to the current tab
     file: "scripts/rectangle.js", // script to inject into page and run in sandbox
     allFrames: false // This injects script into iframes in the page and doesn't work before 4.0.266.0.
   });
 }